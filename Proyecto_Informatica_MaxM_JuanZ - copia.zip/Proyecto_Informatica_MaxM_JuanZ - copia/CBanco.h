#pragma once
#include <string>
class CBanco{
private:
	std::string nombrebanco;
	int clientesnum;
public:
	//Setters
	void setnombrebanco(std::string nameofbank) { this->nombrebanco = nameofbank; }
	void setclientesnum(int numberofclients) { this->clientesnum = numberofclients; }
	//Getters
	std::string getnombrebanco() { return nombrebanco; }
	int getclientesnum() { return clientesnum; }
};

