#pragma once

namespace ProyectoInformaticaMaxMJuanZ {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Formulario
	/// </summary>
	public ref class Formulario : public System::Windows::Forms::Form
	{
	public:
		Formulario(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Formulario()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Button^ BtnConfBanco;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ btnClienteNuevo;
	private: System::Windows::Forms::Button^ btnDeposito;
	private: System::Windows::Forms::Button^ btnTransaccion;
	private: System::Windows::Forms::Button^ btnPrestamo;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ btnregresar1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::TextBox^ txtcuotatclub;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::TextBox^ txtcuotaserviciolinea;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::TextBox^ txtcuotatdebito;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::TextBox^ txtcuotatcredito;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::TextBox^ txtinteresbanco;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Button^ btnregresar2;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::RadioButton^ tarjclubsiono;
	private: System::Windows::Forms::RadioButton^ servlineasiono;
	private: System::Windows::Forms::RadioButton^ tarjdebsiono;
	private: System::Windows::Forms::RadioButton^ tarjcredsiono;
	private: System::Windows::Forms::Label^ label17;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Label^ label16;
	private: System::Windows::Forms::TextBox^ txtCorreoNewC;
	private: System::Windows::Forms::Label^ label15;
	private: System::Windows::Forms::TextBox^ txtTelefonoNewC;
	private: System::Windows::Forms::Label^ label14;
	private: System::Windows::Forms::TextBox^ txtEdadNewC;
	private: System::Windows::Forms::Label^ label13;
	private: System::Windows::Forms::TextBox^ txtIdentificadorNewC;
	private: System::Windows::Forms::Label^ label12;
	private: System::Windows::Forms::TextBox^ txtNombreNewClient;
	private: System::Windows::Forms::Label^ label11;
	private: System::Windows::Forms::Button^ btnregresar3;
	private: System::Windows::Forms::Panel^ panel4;
	private: System::Windows::Forms::Label^ label26;
	private: System::Windows::Forms::Label^ label25;
	private: System::Windows::Forms::Label^ label24;
	private: System::Windows::Forms::Label^ label23;
	private: System::Windows::Forms::Label^ label22;
	private: System::Windows::Forms::Label^ label21;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::TextBox^ textBox4;
	private: System::Windows::Forms::Label^ label20;
	private: System::Windows::Forms::TextBox^ textBox3;
	private: System::Windows::Forms::Label^ label19;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::Button^ btnregresar4;
	private: System::Windows::Forms::Label^ label18;
	private: System::Windows::Forms::Panel^ panel5;
	private: System::Windows::Forms::Label^ label30;
	private: System::Windows::Forms::Label^ label29;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::TextBox^ textBox6;
	private: System::Windows::Forms::Label^ label28;
	private: System::Windows::Forms::Label^ label27;
	private: System::Windows::Forms::TextBox^ textBox5;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Panel^ panel6;
	private: System::Windows::Forms::TextBox^ textBox7;
	private: System::Windows::Forms::Label^ label31;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Label^ label32;
	private: System::Windows::Forms::ComboBox^ comboBox1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->BtnConfBanco = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btnClienteNuevo = (gcnew System::Windows::Forms::Button());
			this->btnDeposito = (gcnew System::Windows::Forms::Button());
			this->btnTransaccion = (gcnew System::Windows::Forms::Button());
			this->btnPrestamo = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->btnregresar1 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->btnregresar2 = (gcnew System::Windows::Forms::Button());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtinteresbanco = (gcnew System::Windows::Forms::TextBox());
			this->txtcuotatcredito = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->txtcuotatdebito = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->txtcuotaserviciolinea = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->txtcuotatclub = (gcnew System::Windows::Forms::TextBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->btnregresar3 = (gcnew System::Windows::Forms::Button());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->txtNombreNewClient = (gcnew System::Windows::Forms::TextBox());
			this->txtIdentificadorNewC = (gcnew System::Windows::Forms::TextBox());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->txtEdadNewC = (gcnew System::Windows::Forms::TextBox());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->txtTelefonoNewC = (gcnew System::Windows::Forms::TextBox());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->txtCorreoNewC = (gcnew System::Windows::Forms::TextBox());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->tarjcredsiono = (gcnew System::Windows::Forms::RadioButton());
			this->tarjdebsiono = (gcnew System::Windows::Forms::RadioButton());
			this->servlineasiono = (gcnew System::Windows::Forms::RadioButton());
			this->tarjclubsiono = (gcnew System::Windows::Forms::RadioButton());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->btnregresar4 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->panel5 = (gcnew System::Windows::Forms::Panel());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->panel6 = (gcnew System::Windows::Forms::Panel());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->panel3->SuspendLayout();
			this->panel4->SuspendLayout();
			this->panel5->SuspendLayout();
			this->panel6->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10));
			this->label1->Location = System::Drawing::Point(12, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(635, 34);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Bienvenido al sistema del banco para administrar distintas operaciones del mismo."
				L"";
			// 
			// BtnConfBanco
			// 
			this->BtnConfBanco->Location = System::Drawing::Point(195, 211);
			this->BtnConfBanco->Name = L"BtnConfBanco";
			this->BtnConfBanco->Size = System::Drawing::Size(191, 112);
			this->BtnConfBanco->TabIndex = 1;
			this->BtnConfBanco->Text = L"Configurar informaci�n del banco (Administrador)";
			this->BtnConfBanco->UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9));
			this->label2->Location = System::Drawing::Point(153, 130);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(290, 18);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Seleccione la operaci�n que quiere realizar";
			// 
			// btnClienteNuevo
			// 
			this->btnClienteNuevo->Location = System::Drawing::Point(417, 211);
			this->btnClienteNuevo->Name = L"btnClienteNuevo";
			this->btnClienteNuevo->Size = System::Drawing::Size(191, 112);
			this->btnClienteNuevo->TabIndex = 3;
			this->btnClienteNuevo->Text = L"Ingresar nuevo cliente";
			this->btnClienteNuevo->UseVisualStyleBackColor = true;
			// 
			// btnDeposito
			// 
			this->btnDeposito->Location = System::Drawing::Point(869, 211);
			this->btnDeposito->Name = L"btnDeposito";
			this->btnDeposito->Size = System::Drawing::Size(191, 112);
			this->btnDeposito->TabIndex = 4;
			this->btnDeposito->Text = L"Realizar dep�sito";
			this->btnDeposito->UseVisualStyleBackColor = true;
			// 
			// btnTransaccion
			// 
			this->btnTransaccion->Location = System::Drawing::Point(646, 211);
			this->btnTransaccion->Name = L"btnTransaccion";
			this->btnTransaccion->Size = System::Drawing::Size(191, 112);
			this->btnTransaccion->TabIndex = 5;
			this->btnTransaccion->Text = L"Realizar transacci�n";
			this->btnTransaccion->UseVisualStyleBackColor = true;
			// 
			// btnPrestamo
			// 
			this->btnPrestamo->Location = System::Drawing::Point(1097, 211);
			this->btnPrestamo->Name = L"btnPrestamo";
			this->btnPrestamo->Size = System::Drawing::Size(191, 112);
			this->btnPrestamo->TabIndex = 6;
			this->btnPrestamo->Text = L"Conceder pr�stamo";
			this->btnPrestamo->UseVisualStyleBackColor = true;
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->panel2);
			this->panel1->Controls->Add(this->label5);
			this->panel1->Controls->Add(this->textBox1);
			this->panel1->Controls->Add(this->label4);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->button1);
			this->panel1->Controls->Add(this->btnregresar1);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(1486, 546);
			this->panel1->TabIndex = 7;
			this->panel1->Visible = false;
			// 
			// btnregresar1
			// 
			this->btnregresar1->Location = System::Drawing::Point(13, 489);
			this->btnregresar1->Name = L"btnregresar1";
			this->btnregresar1->Size = System::Drawing::Size(148, 45);
			this->btnregresar1->TabIndex = 0;
			this->btnregresar1->Text = L"Regresar al men� principal";
			this->btnregresar1->UseVisualStyleBackColor = true;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(799, 315);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(107, 37);
			this->button1->TabIndex = 1;
			this->button1->Text = L"Ingresar";
			this->button1->UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label3->Location = System::Drawing::Point(566, 211);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(318, 25);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Ingrese la contrase�a para ingresar";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10));
			this->label4->Location = System::Drawing::Point(567, 274);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(100, 20);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Contrase�a:";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(689, 272);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(217, 22);
			this->textBox1->TabIndex = 4;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(666, 374);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(159, 16);
			this->label5->TabIndex = 5;
			this->label5->Text = L"Para mostrar si est� mala";
			// 
			// panel2
			// 
			this->panel2->Controls->Add(this->button3);
			this->panel2->Controls->Add(this->txtcuotatclub);
			this->panel2->Controls->Add(this->label10);
			this->panel2->Controls->Add(this->txtcuotaserviciolinea);
			this->panel2->Controls->Add(this->label9);
			this->panel2->Controls->Add(this->txtcuotatdebito);
			this->panel2->Controls->Add(this->label8);
			this->panel2->Controls->Add(this->txtcuotatcredito);
			this->panel2->Controls->Add(this->label7);
			this->panel2->Controls->Add(this->txtinteresbanco);
			this->panel2->Controls->Add(this->label6);
			this->panel2->Controls->Add(this->btnregresar2);
			this->panel2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel2->Location = System::Drawing::Point(0, 0);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(1486, 546);
			this->panel2->TabIndex = 8;
			// 
			// btnregresar2
			// 
			this->btnregresar2->Location = System::Drawing::Point(12, 484);
			this->btnregresar2->Name = L"btnregresar2";
			this->btnregresar2->Size = System::Drawing::Size(161, 50);
			this->btnregresar2->TabIndex = 0;
			this->btnregresar2->Text = L"Regresar al men� principal";
			this->btnregresar2->UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(343, 168);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(198, 16);
			this->label6->TabIndex = 1;
			this->label6->Text = L"Margen de inter�s por pr�stamo";
			// 
			// txtinteresbanco
			// 
			this->txtinteresbanco->Location = System::Drawing::Point(547, 165);
			this->txtinteresbanco->Name = L"txtinteresbanco";
			this->txtinteresbanco->Size = System::Drawing::Size(100, 22);
			this->txtinteresbanco->TabIndex = 2;
			// 
			// txtcuotatcredito
			// 
			this->txtcuotatcredito->Location = System::Drawing::Point(547, 198);
			this->txtcuotatcredito->Name = L"txtcuotatcredito";
			this->txtcuotatcredito->Size = System::Drawing::Size(100, 22);
			this->txtcuotatcredito->TabIndex = 4;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(392, 204);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(145, 16);
			this->label7->TabIndex = 3;
			this->label7->Text = L"Cuota tarjeta de cr�dito";
			// 
			// txtcuotatdebito
			// 
			this->txtcuotatdebito->Location = System::Drawing::Point(547, 232);
			this->txtcuotatdebito->Name = L"txtcuotatdebito";
			this->txtcuotatdebito->Size = System::Drawing::Size(100, 22);
			this->txtcuotatdebito->TabIndex = 6;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(392, 238);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(142, 16);
			this->label8->TabIndex = 5;
			this->label8->Text = L"Cuota tarjeta de d�bito";
			// 
			// txtcuotaserviciolinea
			// 
			this->txtcuotaserviciolinea->Location = System::Drawing::Point(547, 267);
			this->txtcuotaserviciolinea->Name = L"txtcuotaserviciolinea";
			this->txtcuotaserviciolinea->Size = System::Drawing::Size(100, 22);
			this->txtcuotaserviciolinea->TabIndex = 8;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(392, 273);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(142, 16);
			this->label9->TabIndex = 7;
			this->label9->Text = L"Cuota servicio en linea";
			// 
			// txtcuotatclub
			// 
			this->txtcuotatclub->Location = System::Drawing::Point(547, 304);
			this->txtcuotatclub->Name = L"txtcuotatclub";
			this->txtcuotatclub->Size = System::Drawing::Size(100, 22);
			this->txtcuotatclub->TabIndex = 10;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(424, 310);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(110, 16);
			this->label10->TabIndex = 9;
			this->label10->Text = L"Cuota tarjeta club";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(502, 343);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(145, 55);
			this->button3->TabIndex = 11;
			this->button3->Text = L"A�adir nuevos par�metros";
			this->button3->UseVisualStyleBackColor = true;
			// 
			// panel3
			// 
			this->panel3->Controls->Add(this->tarjclubsiono);
			this->panel3->Controls->Add(this->servlineasiono);
			this->panel3->Controls->Add(this->tarjdebsiono);
			this->panel3->Controls->Add(this->tarjcredsiono);
			this->panel3->Controls->Add(this->label17);
			this->panel3->Controls->Add(this->button2);
			this->panel3->Controls->Add(this->label16);
			this->panel3->Controls->Add(this->txtCorreoNewC);
			this->panel3->Controls->Add(this->label15);
			this->panel3->Controls->Add(this->txtTelefonoNewC);
			this->panel3->Controls->Add(this->label14);
			this->panel3->Controls->Add(this->txtEdadNewC);
			this->panel3->Controls->Add(this->label13);
			this->panel3->Controls->Add(this->txtIdentificadorNewC);
			this->panel3->Controls->Add(this->label12);
			this->panel3->Controls->Add(this->txtNombreNewClient);
			this->panel3->Controls->Add(this->label11);
			this->panel3->Controls->Add(this->btnregresar3);
			this->panel3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel3->Location = System::Drawing::Point(0, 0);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(1486, 546);
			this->panel3->TabIndex = 8;
			this->panel3->Visible = false;
			// 
			// btnregresar3
			// 
			this->btnregresar3->Location = System::Drawing::Point(12, 479);
			this->btnregresar3->Name = L"btnregresar3";
			this->btnregresar3->Size = System::Drawing::Size(161, 55);
			this->btnregresar3->TabIndex = 0;
			this->btnregresar3->Text = L"Regresar al men� principal";
			this->btnregresar3->UseVisualStyleBackColor = true;
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(245, 81);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(59, 16);
			this->label11->TabIndex = 1;
			this->label11->Text = L"Nombre:";
			// 
			// txtNombreNewClient
			// 
			this->txtNombreNewClient->Location = System::Drawing::Point(355, 75);
			this->txtNombreNewClient->Name = L"txtNombreNewClient";
			this->txtNombreNewClient->Size = System::Drawing::Size(100, 22);
			this->txtNombreNewClient->TabIndex = 2;
			// 
			// txtIdentificadorNewC
			// 
			this->txtIdentificadorNewC->Location = System::Drawing::Point(355, 109);
			this->txtIdentificadorNewC->Name = L"txtIdentificadorNewC";
			this->txtIdentificadorNewC->Size = System::Drawing::Size(100, 22);
			this->txtIdentificadorNewC->TabIndex = 4;
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(245, 115);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(80, 16);
			this->label12->TabIndex = 3;
			this->label12->Text = L"Identificador";
			// 
			// txtEdadNewC
			// 
			this->txtEdadNewC->Location = System::Drawing::Point(355, 146);
			this->txtEdadNewC->Name = L"txtEdadNewC";
			this->txtEdadNewC->Size = System::Drawing::Size(100, 22);
			this->txtEdadNewC->TabIndex = 6;
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(245, 152);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(40, 16);
			this->label13->TabIndex = 5;
			this->label13->Text = L"Edad";
			// 
			// txtTelefonoNewC
			// 
			this->txtTelefonoNewC->Location = System::Drawing::Point(355, 181);
			this->txtTelefonoNewC->Name = L"txtTelefonoNewC";
			this->txtTelefonoNewC->Size = System::Drawing::Size(100, 22);
			this->txtTelefonoNewC->TabIndex = 8;
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(245, 187);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(61, 16);
			this->label14->TabIndex = 7;
			this->label14->Text = L"Tel�fono";
			// 
			// txtCorreoNewC
			// 
			this->txtCorreoNewC->Location = System::Drawing::Point(355, 218);
			this->txtCorreoNewC->Name = L"txtCorreoNewC";
			this->txtCorreoNewC->Size = System::Drawing::Size(100, 22);
			this->txtCorreoNewC->TabIndex = 10;
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(245, 224);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(48, 16);
			this->label15->TabIndex = 9;
			this->label15->Text = L"Correo";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(263, 43);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(180, 16);
			this->label16->TabIndex = 11;
			this->label16->Text = L"Informaci�n del nuevo cliente";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(583, 252);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(168, 55);
			this->button2->TabIndex = 12;
			this->button2->Text = L"Ingresar nuevo cliente";
			this->button2->UseVisualStyleBackColor = true;
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(580, 43);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(134, 16);
			this->label17->TabIndex = 13;
			this->label17->Text = L"Servicios que solicita";
			// 
			// tarjcredsiono
			// 
			this->tarjcredsiono->AutoSize = true;
			this->tarjcredsiono->Location = System::Drawing::Point(543, 85);
			this->tarjcredsiono->Name = L"tarjcredsiono";
			this->tarjcredsiono->Size = System::Drawing::Size(136, 20);
			this->tarjcredsiono->TabIndex = 14;
			this->tarjcredsiono->TabStop = true;
			this->tarjcredsiono->Text = L"Tarjeta de Cr�dito";
			this->tarjcredsiono->UseVisualStyleBackColor = true;
			// 
			// tarjdebsiono
			// 
			this->tarjdebsiono->AutoSize = true;
			this->tarjdebsiono->Location = System::Drawing::Point(543, 119);
			this->tarjdebsiono->Name = L"tarjdebsiono";
			this->tarjdebsiono->Size = System::Drawing::Size(133, 20);
			this->tarjdebsiono->TabIndex = 15;
			this->tarjdebsiono->TabStop = true;
			this->tarjdebsiono->Text = L"Tarjeta de D�bito";
			this->tarjdebsiono->UseVisualStyleBackColor = true;
			// 
			// servlineasiono
			// 
			this->servlineasiono->AutoSize = true;
			this->servlineasiono->Location = System::Drawing::Point(543, 156);
			this->servlineasiono->Name = L"servlineasiono";
			this->servlineasiono->Size = System::Drawing::Size(131, 20);
			this->servlineasiono->TabIndex = 16;
			this->servlineasiono->TabStop = true;
			this->servlineasiono->Text = L"Servicio en L�nea";
			this->servlineasiono->UseVisualStyleBackColor = true;
			// 
			// tarjclubsiono
			// 
			this->tarjclubsiono->AutoSize = true;
			this->tarjclubsiono->Location = System::Drawing::Point(543, 191);
			this->tarjclubsiono->Name = L"tarjclubsiono";
			this->tarjclubsiono->Size = System::Drawing::Size(165, 20);
			this->tarjclubsiono->TabIndex = 17;
			this->tarjclubsiono->TabStop = true;
			this->tarjclubsiono->Text = L"Tarjeta Club del Banco";
			this->tarjclubsiono->UseVisualStyleBackColor = true;
			// 
			// panel4
			// 
			this->panel4->Controls->Add(this->label26);
			this->panel4->Controls->Add(this->label25);
			this->panel4->Controls->Add(this->label24);
			this->panel4->Controls->Add(this->label23);
			this->panel4->Controls->Add(this->label22);
			this->panel4->Controls->Add(this->label21);
			this->panel4->Controls->Add(this->button4);
			this->panel4->Controls->Add(this->textBox4);
			this->panel4->Controls->Add(this->label20);
			this->panel4->Controls->Add(this->textBox3);
			this->panel4->Controls->Add(this->label19);
			this->panel4->Controls->Add(this->textBox2);
			this->panel4->Controls->Add(this->btnregresar4);
			this->panel4->Controls->Add(this->label18);
			this->panel4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel4->Location = System::Drawing::Point(0, 0);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(1486, 546);
			this->panel4->TabIndex = 9;
			this->panel4->Visible = false;
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(497, 264);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(106, 16);
			this->label18->TabIndex = 0;
			this->label18->Text = L"Ingrese el monto";
			// 
			// btnregresar4
			// 
			this->btnregresar4->Location = System::Drawing::Point(16, 482);
			this->btnregresar4->Name = L"btnregresar4";
			this->btnregresar4->Size = System::Drawing::Size(157, 52);
			this->btnregresar4->TabIndex = 1;
			this->btnregresar4->Text = L"Regresar al men� principal";
			this->btnregresar4->UseVisualStyleBackColor = true;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(637, 261);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 22);
			this->textBox2->TabIndex = 2;
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(536, 180);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(100, 22);
			this->textBox3->TabIndex = 4;
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(430, 186);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(78, 16);
			this->label19->TabIndex = 3;
			this->label19->Text = L"ID remitente";
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(796, 177);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(100, 22);
			this->textBox4->TabIndex = 6;
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(690, 183);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(93, 16);
			this->label20->TabIndex = 5;
			this->label20->Text = L"ID destinatario";
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(796, 229);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(119, 57);
			this->button4->TabIndex = 7;
			this->button4->Text = L"Realizar dep�sito";
			this->button4->UseVisualStyleBackColor = true;
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(1056, 184);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(51, 16);
			this->label21->TabIndex = 8;
			this->label21->Text = L"label21";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(1059, 229);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(51, 16);
			this->label22->TabIndex = 9;
			this->label22->Text = L"label22";
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(1062, 269);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(51, 16);
			this->label23->TabIndex = 10;
			this->label23->Text = L"label23";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(1193, 189);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(51, 16);
			this->label24->TabIndex = 11;
			this->label24->Text = L"label24";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(1196, 228);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(51, 16);
			this->label25->TabIndex = 12;
			this->label25->Text = L"label25";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(1196, 269);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(51, 16);
			this->label26->TabIndex = 13;
			this->label26->Text = L"label26";
			// 
			// panel5
			// 
			this->panel5->Controls->Add(this->label30);
			this->panel5->Controls->Add(this->label29);
			this->panel5->Controls->Add(this->button6);
			this->panel5->Controls->Add(this->textBox6);
			this->panel5->Controls->Add(this->label28);
			this->panel5->Controls->Add(this->label27);
			this->panel5->Controls->Add(this->textBox5);
			this->panel5->Controls->Add(this->button5);
			this->panel5->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel5->Location = System::Drawing::Point(0, 0);
			this->panel5->Name = L"panel5";
			this->panel5->Size = System::Drawing::Size(1486, 546);
			this->panel5->TabIndex = 10;
			this->panel5->Visible = false;
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(12, 482);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(157, 52);
			this->button5->TabIndex = 2;
			this->button5->Text = L"Regresar al men� principal";
			this->button5->UseVisualStyleBackColor = true;
			// 
			// textBox5
			// 
			this->textBox5->Location = System::Drawing::Point(484, 125);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(100, 22);
			this->textBox5->TabIndex = 3;
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(414, 132);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(44, 16);
			this->label27->TabIndex = 4;
			this->label27->Text = L"Monto";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(436, 174);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(20, 16);
			this->label28->TabIndex = 5;
			this->label28->Text = L"ID";
			// 
			// textBox6
			// 
			this->textBox6->Location = System::Drawing::Point(484, 165);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(100, 22);
			this->textBox6->TabIndex = 6;
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(484, 208);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(108, 56);
			this->button6->TabIndex = 7;
			this->button6->Text = L"Ingresar dep�sito";
			this->button6->UseVisualStyleBackColor = true;
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(681, 125);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(51, 16);
			this->label29->TabIndex = 8;
			this->label29->Text = L"label29";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(786, 125);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(51, 16);
			this->label30->TabIndex = 9;
			this->label30->Text = L"label30";
			// 
			// panel6
			// 
			this->panel6->Controls->Add(this->button8);
			this->panel6->Controls->Add(this->label32);
			this->panel6->Controls->Add(this->comboBox1);
			this->panel6->Controls->Add(this->textBox7);
			this->panel6->Controls->Add(this->label31);
			this->panel6->Controls->Add(this->button7);
			this->panel6->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel6->Location = System::Drawing::Point(0, 0);
			this->panel6->Name = L"panel6";
			this->panel6->Size = System::Drawing::Size(1486, 546);
			this->panel6->TabIndex = 11;
			this->panel6->Visible = false;
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(12, 482);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(157, 52);
			this->button7->TabIndex = 3;
			this->button7->Text = L"Regresar al men� principal";
			this->button7->UseVisualStyleBackColor = true;
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(464, 147);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(153, 16);
			this->label31->TabIndex = 4;
			this->label31->Text = L"Ingrese monto solicitado";
			// 
			// textBox7
			// 
			this->textBox7->Location = System::Drawing::Point(653, 147);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(125, 22);
			this->textBox7->TabIndex = 5;
			this->textBox7->TextChanged += gcnew System::EventHandler(this, &Formulario::textBox7_TextChanged);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(653, 189);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(125, 24);
			this->comboBox1->TabIndex = 6;
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(436, 197);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(192, 16);
			this->label32->TabIndex = 7;
			this->label32->Text = L"Seleccione cantidad de cuotas";
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(667, 233);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(111, 52);
			this->button8->TabIndex = 8;
			this->button8->Text = L"Ingresar pr�stamo";
			this->button8->UseVisualStyleBackColor = true;
			// 
			// Formulario
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1486, 546);
			this->Controls->Add(this->panel6);
			this->Controls->Add(this->panel5);
			this->Controls->Add(this->panel4);
			this->Controls->Add(this->panel3);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->btnPrestamo);
			this->Controls->Add(this->btnTransaccion);
			this->Controls->Add(this->btnDeposito);
			this->Controls->Add(this->btnClienteNuevo);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->BtnConfBanco);
			this->Controls->Add(this->label1);
			this->Name = L"Formulario";
			this->Text = L"Administrador Bancario";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->panel4->ResumeLayout(false);
			this->panel4->PerformLayout();
			this->panel5->ResumeLayout(false);
			this->panel5->PerformLayout();
			this->panel6->ResumeLayout(false);
			this->panel6->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void textBox7_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
};
}
