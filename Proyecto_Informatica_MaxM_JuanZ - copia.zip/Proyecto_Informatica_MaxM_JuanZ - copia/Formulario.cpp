#include "pch.h"
#include "Formulario.h"
using namespace ProyectoInformaticaMaxMJuanZ;

void main() {
	Application::EnableVisualStyles();
	Application::Run(gcnew Formulario());
}