#pragma once
#include <string>
class CCliente { //Contiene la informaci�n de cada cliente, LISTA
private:
	std::string nombre_cliente;
	int edad;
	std::string identificador;
	std::string numero_telefono;
	std::string correo;
public:
	//setters
	void setnombre_cliente(std::string nombrecliente) { this->nombre_cliente = nombrecliente; }
	void setedad(int age) { this->edad = age; }
	void setidentificador(std::string id) { this->identificador = id; }
	void setnumero_telefono(std::string telefono) { this->numero_telefono = telefono; }
	void setcorreo(std::string mail) { this->correo = mail; }
	//getters
	std::string getnombre_cliente() { return nombre_cliente; }
	int getedad() { return edad; }
	std::string getidentificador() { return identificador; }
	std::string getnumero_telefono() { return numero_telefono; }
	std::string getcorreo() { return correo; }
};

